//#region extension/src/background/service-worker.ts
/**
* Sahayak AI Extension — Background Service Worker
* 
* Source of Truth: docs/source-of-truth/ARCHITECTURE.md Section 29 & SECURITY.md Section 10
* Phase: P08 — Browser Extension
* 
* Coordinates:
* - Extension lifecycle & installation
* - Chrome side panel opening behavior
* - Tab updates across government portals
*/
if (typeof chrome !== "undefined" && chrome.sidePanel && chrome.sidePanel.setPanelBehavior) chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch((error) => {
	console.warn("[Sahayak ServiceWorker] Unable to set side panel behavior:", error);
});
if (typeof chrome !== "undefined" && chrome.runtime?.onInstalled) chrome.runtime.onInstalled.addListener((details) => {
	if (details.reason === "install") console.log("[Sahayak ServiceWorker] Extension installed successfully.");
});
if (typeof chrome !== "undefined" && chrome.tabs?.onUpdated) chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
	if (changeInfo.status === "complete" && tab.url) {
		if ((tab.url.includes(".gov.in") || tab.url.includes(".mahaonline.gov.in") || tab.url.includes("localhost") || tab.url.includes("127.0.0.1")) && chrome.sidePanel?.setOptions) chrome.sidePanel.setOptions({
			tabId,
			path: "sidepanel.html",
			enabled: true
		}).catch(() => {});
	}
});
//#endregion
