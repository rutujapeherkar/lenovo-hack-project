var SahayakContentScript = (function(exports) {
	Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
	//#region src/core/shared/validators.ts
	/** Approved government top-level and second-level domain suffixes */
	var APPROVED_GOVERNMENT_DOMAINS = [
		".gov.in",
		".nic.in",
		".mahaonline.gov.in",
		".eci.gov.in",
		".maharashtra.gov.in",
		".mahafood.gov.in"
	];
	/**
	* Validates that an official URL uses HTTPS and belongs to an approved government domain.
	* Per OFFICIAL-SOURCES.md & SECURITY.md, official URLs must never be synthetic or insecure.
	*/
	function validateOfficialUrl(urlString) {
		if (typeof urlString !== "string" || !urlString.trim()) return false;
		try {
			const parsed = new URL(urlString);
			if (parsed.protocol !== "https:") return false;
			const hostname = parsed.hostname.toLowerCase();
			return APPROVED_GOVERNMENT_DOMAINS.some((approved) => hostname.endsWith(approved) || hostname === approved.replace(/^\./, ""));
		} catch {
			return false;
		}
	}
	/** Type guard for LocalizedText ({ en: string; mr: string; hi: string }) */
	function isLocalizedText(val) {
		if (!val || typeof val !== "object") return false;
		const obj = val;
		return typeof obj.en === "string" && obj.en.trim().length > 0 && typeof obj.mr === "string" && obj.mr.trim().length > 0 && typeof obj.hi === "string" && obj.hi.trim().length > 0;
	}
	/** Type guard for OfficialSource */
	function isOfficialSource(val) {
		if (!val || typeof val !== "object") return false;
		const obj = val;
		const hasValidName = typeof obj.name === "string" && obj.name.trim().length > 0;
		const hasValidUrl = typeof obj.url === "string" && validateOfficialUrl(obj.url);
		const hasValidTimestamp = obj.lastVerified === void 0 || typeof obj.lastVerified === "string";
		return hasValidName && hasValidUrl && hasValidTimestamp;
	}
	/** Type guard for TaskStep */
	function isTaskStep(val) {
		if (!val || typeof val !== "object") return false;
		const obj = val;
		return typeof obj.id === "string" && obj.id.trim().length > 0 && isLocalizedText(obj.title) && isLocalizedText(obj.description) && [
			"completed",
			"current",
			"upcoming"
		].includes(obj.status);
	}
	/** Type guard for Service */
	function isService(val) {
		if (!val || typeof val !== "object") return false;
		const obj = val;
		return typeof obj.id === "string" && obj.id.trim().length > 0 && isLocalizedText(obj.name) && isLocalizedText(obj.description) && typeof obj.category === "string" && obj.state === "Maharashtra" && Array.isArray(obj.documents) && obj.documents.every((d) => typeof d === "string") && Array.isArray(obj.steps) && obj.steps.length > 0 && obj.steps.every(isTaskStep) && isOfficialSource(obj.officialSource);
	}
	/** Type guard for Scheme */
	function isScheme(val) {
		if (!val || typeof val !== "object") return false;
		const obj = val;
		return typeof obj.id === "string" && obj.id.trim().length > 0 && isLocalizedText(obj.name) && obj.state === "Maharashtra" && typeof obj.category === "string" && Array.isArray(obj.eligibility) && obj.eligibility.length > 0 && obj.eligibility.every((e) => typeof e === "string") && Array.isArray(obj.benefits) && obj.benefits.length > 0 && obj.benefits.every((b) => typeof b === "string") && Array.isArray(obj.documents) && obj.documents.every((d) => typeof d === "string") && isOfficialSource(obj.officialSource) && (obj.lastVerified === void 0 || typeof obj.lastVerified === "string");
	}
	/** Type guard for Portal */
	function isPortal(val) {
		if (!val || typeof val !== "object") return false;
		const obj = val;
		return typeof obj.id === "string" && obj.id.trim().length > 0 && typeof obj.name === "string" && typeof obj.domain === "string" && obj.state === "Maharashtra" && typeof obj.supported === "boolean";
	}
	/** Type guard for ExtensionMessage */
	function isExtensionMessage(val) {
		if (!val || typeof val !== "object") return false;
		const obj = val;
		switch (obj.type) {
			case "GET_PAGE_CONTEXT":
			case "GET_CURRENT_FORM": return true;
			case "HIGHLIGHT_FIELD": return typeof obj.fieldId === "string" && obj.fieldId.trim().length > 0;
			case "CLEAR_HIGHLIGHT": return obj.fieldId === void 0 || typeof obj.fieldId === "string";
			default: return false;
		}
	}
	//#endregion
	//#region src/data/maharashtra/portals.json
	var portals_default = [
		{
			"id": "aaple-sarkar",
			"name": "Aaple Sarkar Citizen Services Portal",
			"domain": "aaplesarkar.mahaonline.gov.in",
			"state": "Maharashtra",
			"supported": true
		},
		{
			"id": "mahadbt",
			"name": "MahaDBT Direct Benefit Transfer",
			"domain": "mahadbt.maharashtra.gov.in",
			"state": "Maharashtra",
			"supported": true
		},
		{
			"id": "rcms-maharashtra",
			"name": "Ration Card Management System (RCMS) Maharashtra",
			"domain": "rcms.mahafood.gov.in",
			"state": "Maharashtra",
			"supported": true
		},
		{
			"id": "divyang-sahayak",
			"name": "Divyang Sahayak Disability Empowerment Portal",
			"domain": "divyangsahayak.maharashtra.gov.in",
			"state": "Maharashtra",
			"supported": true
		},
		{
			"id": "eci-voters",
			"name": "Election Commission of India Voters' Services",
			"domain": "voters.eci.gov.in",
			"state": "Maharashtra",
			"supported": true
		},
		{
			"id": "myscheme",
			"name": "myScheme National Scheme Discovery Portal",
			"domain": "myscheme.gov.in",
			"state": "Maharashtra",
			"supported": true
		},
		{
			"id": "nsp",
			"name": "National Scholarship Portal (NSP)",
			"domain": "scholarships.gov.in",
			"state": "Maharashtra",
			"supported": true
		},
		{
			"id": "udid",
			"name": "Unique Disability ID (UDID) Swavlamban",
			"domain": "swavlambancard.gov.in",
			"state": "Maharashtra",
			"supported": true
		},
		{
			"id": "pmkisan",
			"name": "PM-KISAN Samman Nidhi Portal",
			"domain": "pmkisan.gov.in",
			"state": "Maharashtra",
			"supported": true
		},
		{
			"id": "sjsa-maharashtra",
			"name": "Social Justice and Special Assistance Department",
			"domain": "sjsa.maharashtra.gov.in",
			"state": "Maharashtra",
			"supported": true
		}
	];
	//#endregion
	//#region src/data/maharashtra/services.json
	var services_default = /*#__PURE__*/ JSON.parse("[{\"id\":\"income-certificate\",\"name\":{\"en\":\"Income Certificate\",\"mr\":\"उत्पन्न प्रमाणपत्र\",\"hi\":\"आय प्रमाण पत्र\"},\"description\":{\"en\":\"Official state certificate verifying annual household income issued by the Revenue Department, required for fee concessions, scholarships, and social welfare schemes.\",\"mr\":\"महसूल विभागामार्फत जारी केलेले अधिकृत वार्षिक कौटुंबिक उत्पन्न प्रमाणपत्र, जे शैक्षणिक शुल्क सवलत, शिष्यवृत्ती आणि शासकीय योजनांसाठी आवश्यक असते.\",\"hi\":\"राजस्व विभाग द्वारा जारी आधिकारिक वार्षिक पारिवारिक आय प्रमाण पत्र, जो शुल्क छूट, छात्रवृत्ति और सामाजिक कल्याण योजनाओं के लिए आवश्यक है।\"},\"category\":\"Revenue & Citizen Certificates\",\"state\":\"Maharashtra\",\"documents\":[\"Proof of Identity (Aadhaar Card / Voter ID / Passport)\",\"Proof of Address (Ration Card / Electricity Bill / Telephone Bill)\",\"Income Proof (Salary Slip / Form 16 / Income Tax Return / Talathi Verification Report)\",\"Recent passport-sized photograph (3.5cm x 4.5cm)\",\"Self-Declaration Affidavit in standard prescribed format\"],\"steps\":[{\"id\":\"step-1-gather-docs\",\"title\":{\"en\":\"Assemble Required Documents\",\"mr\":\"आवश्यक कागदपत्रे गोळा करा\",\"hi\":\"आवश्यक दस्तावेज एकत्र करें\"},\"description\":{\"en\":\"Keep scanned copies of your Aadhaar card, ration card, income proof (salary slip or Talathi report), and self-declaration ready in PDF/JPEG format under 256 KB.\",\"mr\":\"आपले आधार कार्ड, रेशन कार्ड, उत्पन्न पुरावा (वेतन पावती किंवा तलाठी अहवाल) आणि स्वयंघोषणापत्राची स्कॅन केलेली प्रत २५६ केबी पेक्षा कमी आकारात तयार ठेवा.\",\"hi\":\"अपना आधार कार्ड, राशन कार्ड, आय प्रमाण (वेतन पर्ची या तलाठी रिपोर्ट) और स्व-घोषणा पत्र की स्कैन कॉपी 256 KB से कम आकार में तैयार रखें।\"},\"status\":\"current\"},{\"id\":\"step-2-portal-register\",\"title\":{\"en\":\"Log In to Aaple Sarkar Portal\",\"mr\":\"आपले सरकार पोर्टलवर लॉगिन करा\",\"hi\":\"आपले सरकार पोर्टल पर लॉगिन करें\"},\"description\":{\"en\":\"Visit the official Aaple Sarkar portal and log in using your registered credentials, or complete new citizen registration using Aadhaar authentication.\",\"mr\":\"अधिकृत आपले सरकार पोर्टलवर जा आणि आपल्या नोंदणीकृत खात्याने लॉगिन करा किंवा आधार प्रमाणीकरणाद्वारे नवीन वापरकर्ता म्हणून नोंदणी करा.\",\"hi\":\"आधिकारिक आपले सरकार पोर्टल पर जाएं और अपने पंजीकृत खाते से लॉगिन करें, या आधार प्रमाणीकरण के साथ नए उपयोगकर्ता के रूप में पंजीकरण करें।\"},\"status\":\"upcoming\"},{\"id\":\"step-3-select-service\",\"title\":{\"en\":\"Select Revenue Department Services\",\"mr\":\"महसूल विभाग सेवा निवडा\",\"hi\":\"राजस्व विभाग सेवा चुनें\"},\"description\":{\"en\":\"Navigate to Revenue Department services, select 'Income Certificate', and click 'Apply'.\",\"mr\":\"महसूल विभाग सेवांवर जा, 'उत्पन्न प्रमाणपत्र' निवडा आणि 'अर्ज करा' वर क्लिक करा.\",\"hi\":\"राजस्व विभाग की सेवाओं पर जाएं, 'आय प्रमाण पत्र' चुनें और 'आवेदन करें' पर क्लिक करें।\"},\"status\":\"upcoming\"},{\"id\":\"step-4-fill-details\",\"title\":{\"en\":\"Fill Applicant & Household Income Details\",\"mr\":\"अर्जदार आणि कौटुंबिक उत्पन्नाचा तपशील भरा\",\"hi\":\"आवेदक और पारिवारिक आय का विवरण भरें\"},\"description\":{\"en\":\"Enter applicant personal details, district, taluka, village, and accurate income breakdown for the past 3 financial years.\",\"mr\":\"अर्जदाराचा वैयक्तिक तपशील, जिल्हा, तालुका, गाव आणि मागील ३ आर्थिक वर्षांचे अचूक उत्पन्नाचे विवरण भरा.\",\"hi\":\"आवेदक का व्यक्तिगत विवरण, जिला, तहसील, गांव और पिछले 3 वित्तीय वर्षों की सटीक आय का विवरण दर्ज करें।\"},\"status\":\"upcoming\"},{\"id\":\"step-5-upload-pay\",\"title\":{\"en\":\"Upload Documents & Pay Statutory Fee\",\"mr\":\"कागदपत्रे अपलोड करा आणि सरकारी शुल्क भरा\",\"hi\":\"दस्तावेज अपलोड करें और सरकारी शुल्क का भुगतान करें\"},\"description\":{\"en\":\"Upload verified document proofs and complete the nominal statutory service fee (approx. ₹33.60) via official payment gateway.\",\"mr\":\"सत्यापित कागदपत्रे अपलोड करा आणि अधिकृत पेमेंट गेटवेद्वारे नाममात्र सरकारी शुल्क (अंदाजे ₹३३.६०) भरा.\",\"hi\":\"सत्यापित दस्तावेज अपलोड करें और आधिकारिक भुगतान गेटवे के माध्यम से मामूली सरकारी शुल्क (लगभग ₹33.60) का भुगतान करें।\"},\"status\":\"upcoming\"},{\"id\":\"step-6-track-download\",\"title\":{\"en\":\"Track Application & Download Certificate\",\"mr\":\"अर्जाचा मागोवा घ्या आणि प्रमाणपत्र डाउनलोड करा\",\"hi\":\"आवेदन ट्रैक करें और प्रमाण पत्र डाउनलोड करें\"},\"description\":{\"en\":\"Track progress using the generated Application ID. Once approved by the Tehsildar (RTS timeline: 15 days), download the digitally signed certificate.\",\"mr\":\"प्राप्त अर्ज क्रमांकाद्वारे अर्जाचा मागोवा घ्या. तहसीलदारांकडून मंजुरी मिळाल्यानंतर (आरटीएस कालमर्यादा: १५ दिवस), डिजिटल स्वाक्षरी केलेले प्रमाणपत्र डाउनलोड करा.\",\"hi\":\"प्राप्त आवेदन संख्या के माध्यम से आवेदन को ट्रैक करें। तहसीलदार द्वारा स्वीकृति मिलने के बाद (आरटीएस समयसीमा: 15 दिन), डिजिटल रूप से हस्ताक्षरित प्रमाण पत्र डाउनलोड करें।\"},\"status\":\"upcoming\"}],\"officialSource\":{\"name\":\"Aaple Sarkar — Revenue Department, Government of Maharashtra\",\"url\":\"https://aaplesarkar.mahaonline.gov.in/en/\",\"lastVerified\":\"2026-09-25\"}},{\"id\":\"domicile-certificate\",\"name\":{\"en\":\"Age, Nationality and Domicile Certificate\",\"mr\":\"वय, अधिवास आणि राष्ट्रीयत्व प्रमाणपत्र\",\"hi\":\"आयु, अधिवास और राष्ट्रीयता प्रमाण पत्र\"},\"description\":{\"en\":\"Authoritative certificate proving legal residence in Maharashtra for at least 15 continuous years, essential for state quota college admissions, scholarships, and Maharashtra state recruitment.\",\"mr\":\"महाराष्ट्रामध्ये सलग किमान १५ वर्षे वास्तव्याचा अधिकृत पुरावा देणारे प्रमाणपत्र, जे राज्य कोट्यातील प्रवेश, शिष्यवृत्ती आणि शासकीय नोकऱ्यांसाठी अनिवार्य असते.\",\"hi\":\"महाराष्ट्र में कम से कम 15 निरंतर वर्षों के निवास का आधिकारिक प्रमाण पत्र, जो राज्य कोटे के तहत प्रवेश, छात्रवृत्ति और सरकारी भर्ती के लिए अनिवार्य है।\"},\"category\":\"Revenue & Citizen Certificates\",\"state\":\"Maharashtra\",\"documents\":[\"Proof of Identity (Aadhaar Card / Voter ID / Passport)\",\"Proof of Address (Ration Card / Electricity Bill / Telephone Bill)\",\"Proof of Continuous 15-Year Residence in Maharashtra (School Leaving Certificate / Ration Cards / Property Tax receipts / Electricity bills)\",\"Birth Certificate of Applicant (or School Leaving Certificate showing birthplace in Maharashtra)\",\"Affidavit affirming domicile status in the prescribed format\"],\"steps\":[{\"id\":\"step-1-gather-domicile-docs\",\"title\":{\"en\":\"Compile 15-Year Continuous Residence Proof\",\"mr\":\"१५ वर्षांच्या सलग वास्तव्याचे पुरावे जमा करा\",\"hi\":\"15 वर्ष के निरंतर निवास के प्रमाण एकत्र करें\"},\"description\":{\"en\":\"Gather residence proof establishing uninterrupted stay in Maharashtra for at least 15 years alongside identity and birth records.\",\"mr\":\"ओळख आणि जन्म पुराव्यासोबतच महाराष्ट्रात किमान १५ वर्षे सलग वास्तव्याचा पुरावा देणारी कागदपत्रे जमा करा.\",\"hi\":\"पहचान और जन्म प्रमाण के साथ महाराष्ट्र में कम से कम 15 वर्ष के निरंतर प्रवास को स्थापित करने वाले दस्तावेज एकत्र करें।\"},\"status\":\"current\"},{\"id\":\"step-2-login-aaple-sarkar\",\"title\":{\"en\":\"Access Aaple Sarkar Portal\",\"mr\":\"आपले सरकार पोर्टलवर प्रवेश करा\",\"hi\":\"आपले सरकार पोर्टल पर जाएं\"},\"description\":{\"en\":\"Log in with registered citizen credentials on the Aaple Sarkar portal.\",\"mr\":\"आपले सरकार पोर्टलवर नोंदणीकृत नागरिक खात्याद्वारे लॉगिन करा.\",\"hi\":\"आपले सरकार पोर्टल पर पंजीकृत नागरिक खाते से लॉगिन करें।\"},\"status\":\"upcoming\"},{\"id\":\"step-3-select-domicile-service\",\"title\":{\"en\":\"Select Age, Nationality & Domicile\",\"mr\":\"वय, राष्ट्रीयत्व आणि अधिवास प्रमाणपत्र निवडा\",\"hi\":\"आयु, राष्ट्रीयता और अधिवास प्रमाण पत्र चुनें\"},\"description\":{\"en\":\"Select the Revenue Department and click on 'Age Nationality and Domicile Certificate'.\",\"mr\":\"महसूल विभाग निवडून 'वय, राष्ट्रीयत्व आणि अधिवास प्रमाणपत्र' सेवेवर क्लिक करा.\",\"hi\":\"राजस्व विभाग चुनें और 'आयु, राष्ट्रीयता और अधिवास प्रमाण पत्र' सेवा पर क्लिक करें।\"},\"status\":\"upcoming\"},{\"id\":\"step-4-complete-form\",\"title\":{\"en\":\"Fill Application Details\",\"mr\":\"अर्जातील तपशील पूर्ण करा\",\"hi\":\"आवेदन का विवरण पूरा करें\"},\"description\":{\"en\":\"Enter applicant residence history from birth or for the past 15 years, father/guardian details, and reason for application.\",\"mr\":\"जन्मापासून किंवा मागील १५ वर्षांच्या वास्तव्याचा इतिहास, वडील/पालकांचा तपशील आणि अर्जाचे कारण भरा.\",\"hi\":\"जन्म से या पिछले 15 वर्षों के निवास का इतिहास, पिता/अभिभावक का विवरण और आवेदन का कारण दर्ज करें।\"},\"status\":\"upcoming\"},{\"id\":\"step-5-upload-pay-domicile\",\"title\":{\"en\":\"Upload Documents & Complete Fee Payment\",\"mr\":\"कागदपत्रे अपलोड करा आणि शुल्क भरा\",\"hi\":\"दस्तावेज अपलोड करें और शुल्क का भुगतान करें\"},\"description\":{\"en\":\"Upload scanned documents and make online payment of the statutory fee (approx. ₹33.60).\",\"mr\":\"स्कॅन केलेली कागदपत्रे अपलोड करा आणि सरकारी शुल्काचा (अंदाजे ₹३३.६०) ऑनलाइन भरणा करा.\",\"hi\":\"स्कैन किए गए दस्तावेज अपलोड करें और सरकारी शुल्क (लगभग ₹33.60) का ऑनलाइन भुगतान करें।\"},\"status\":\"upcoming\"},{\"id\":\"step-6-tehsildar-verification\",\"title\":{\"en\":\"Verification and Certificate Issuance\",\"mr\":\"पडताळणी आणि प्रमाणपत्र वितरण\",\"hi\":\"सत्यापन और प्रमाण पत्र जारी करना\"},\"description\":{\"en\":\"The application is verified by the Tehsildar or Sub-Divisional Officer. Download the digitally signed certificate within RTS stipulated timeline (15 days).\",\"mr\":\"तहसीलदार किंवा उपविभागीय अधिकाऱ्यांकडून अर्जाची छाननी केली जाते. १५ दिवसांच्या आरटीएस मुदतीत डिजिटल स्वाक्षरी असलेले प्रमाणपत्र डाउनलोड करा.\",\"hi\":\"तहसीलदार या उप-विभागीय अधिकारी द्वारा आवेदन का सत्यापन किया जाता है। आरटीएस की 15 दिनों की समयसीमा में डिजिटल हस्ताक्षरित प्रमाण पत्र डाउनलोड करें।\"},\"status\":\"upcoming\"}],\"officialSource\":{\"name\":\"Aaple Sarkar — Revenue Department, Government of Maharashtra\",\"url\":\"https://aaplesarkar.mahaonline.gov.in/en/\",\"lastVerified\":\"2026-09-25\"}},{\"id\":\"ration-card-member-addition\",\"name\":{\"en\":\"Ration Card Member Addition\",\"mr\":\"रेशन कार्डमध्ये नवीन सदस्याचे नाव समाविष्ट करणे\",\"hi\":\"राशन कार्ड में नए सदस्य का नाम जोड़ना\"},\"description\":{\"en\":\"Public service to add a family member (newborn child, newly married spouse, or dependent relative) to an active Maharashtra National Food Security Act (NFSA) or State Ration Card via RCMS.\",\"mr\":\"आरसीएमएस पोर्टलद्वारे सक्रिय महाराष्ट्र राष्ट्रीय अन्न सुरक्षा (एनएफएसए) किंवा राज्य रेशन कार्डमध्ये कुटुंबातील नवीन सदस्याचे (नवजात बालक किंवा नवविवाहित सून) नाव समाविष्ट करण्याची सेवा.\",\"hi\":\"आरसीएमएस पोर्टल के माध्यम से सक्रिय महाराष्ट्र राष्ट्रीय खाद्य सुरक्षा (एनएफएसए) या राज्य राशन कार्ड में परिवार के नए सदस्य (नवजात शिशु या नवविवाहित पत्नी) का नाम जोड़ने की सार्वजनिक सेवा।\"},\"category\":\"Food, Civil Supplies & Consumer Protection\",\"state\":\"Maharashtra\",\"documents\":[\"Original Active Ration Card copy\",\"Aadhaar Card of the member to be added (Mandatory)\",\"Birth Certificate (in case of newborn child under 5 years)\",\"Marriage Certificate and Deletion Certificate/Surrender Certificate from previous ration card (in case of spouse)\",\"Head of Family's Identity Proof & Passport-sized photo\"],\"steps\":[{\"id\":\"step-1-gather-member-docs\",\"title\":{\"en\":\"Obtain Deletion or Birth Certificate\",\"mr\":\"नाव कमी केल्याचा दाखला किंवा जन्म दाखला मिळवा\",\"hi\":\"नाम हटाने का प्रमाण पत्र या जन्म प्रमाण पत्र प्राप्त करें\"},\"description\":{\"en\":\"Ensure the new member is deleted from their earlier ration card (for marriage) or obtain the birth certificate (for child). Keep Aadhaar linked.\",\"mr\":\"विवाह झाल्यास आधीच्या रेशन कार्डमधून नाव कमी केल्याचा दाखला (डिलीशन सर्टिफिकेट) मिळवा किंवा बालकाचा जन्म दाखला व आधार कार्ड तयार ठेवा.\",\"hi\":\"विवाह के मामले में पिछले राशन कार्ड से नाम हटाने का प्रमाण पत्र प्राप्त करें या बच्चे का जन्म प्रमाण पत्र और आधार कार्ड तैयार रखें।\"},\"status\":\"current\"},{\"id\":\"step-2-access-rcms\",\"title\":{\"en\":\"Access RCMS Maharashtra Portal\",\"mr\":\"आरसीएमएस महाराष्ट्र पोर्टलवर जा\",\"hi\":\"आरसीएमएस महाराष्ट्र पोर्टल पर जाएं\"},\"description\":{\"en\":\"Open the official Food, Civil Supplies and Consumer Protection Department RCMS portal.\",\"mr\":\"अन्न, नागरी पुरवठा व ग्राहक संरक्षण विभागाच्या अधिकृत आरसीएमएस पोर्टलवर जा.\",\"hi\":\"खाद्य, नागरिक आपूर्ति एवं उपभोक्ता संरक्षण विभाग के आधिकारिक आरसीएमएस पोर्टल पर जाएं।\"},\"status\":\"upcoming\"},{\"id\":\"step-3-select-member-addition\",\"title\":{\"en\":\"Select 'Add Member' Online Service\",\"mr\":\"'सदस्य जोडा' ऑनलाइन सेवा निवडा\",\"hi\":\"'सदस्य जोड़ें' ऑनलाइन सेवा चुनें\"},\"description\":{\"en\":\"Log in to citizen services with Ration Card number and select the 'Add Member' modification service.\",\"mr\":\"रेशन कार्ड क्रमांकाद्वारे नागरिक सेवांमध्ये लॉगिन करा आणि 'नवीन सदस्य समाविष्ट करा' पर्याय निवडा.\",\"hi\":\"राशन कार्ड नंबर के साथ नागरिक सेवाओं में लॉगिन करें और 'नया सदस्य जोड़ें' विकल्प चुनें।\"},\"status\":\"upcoming\"},{\"id\":\"step-4-enter-member-info\",\"title\":{\"en\":\"Input New Member Details & Aadhaar\",\"mr\":\"नवीन सदस्याचा तपशील आणि आधार क्रमांक भरा\",\"hi\":\"नए सदस्य का विवरण और आधार नंबर भरें\"},\"description\":{\"en\":\"Enter the full name (English and Marathi), relationship with head of family, gender, date of birth, and verified 12-digit Aadhaar number.\",\"mr\":\"नवीन सदस्याचे पूर्ण नाव (इंग्रजी आणि मराठी), कुटुंब प्रमुखाशी नाते, लिंग, जन्मतारीख आणि आधार क्रमांक नोंदवा.\",\"hi\":\"नए सदस्य का पूरा नाम (अंग्रेजी और मराठी), परिवार के मुखिया से संबंध, लिंग, जन्म तिथि और आधार नंबर दर्ज करें।\"},\"status\":\"upcoming\"},{\"id\":\"step-5-upload-proofs-submit\",\"title\":{\"en\":\"Upload Proofs & Submit to Supply Officer\",\"mr\":\"कागदपत्रे अपलोड करा आणि पुरवठा निरीक्षकाकडे सादर करा\",\"hi\":\"दस्तावेज अपलोड करें और आपूर्ति अधिकारी को सबमिट करें\"},\"description\":{\"en\":\"Upload supporting proof files and submit. The application is routed to the local Taluka Supply Officer (TSI / DSO) for field verification.\",\"mr\":\"संबंधित पुरावे अपलोड करून अर्ज सादर करा. अर्ज पडताळणीसाठी स्थानिक तालुका पुरवठा अधिकाऱ्यांकडे (टीएसओ) वर्ग केला जातो.\",\"hi\":\"सहायक दस्तावेज अपलोड करें और सबमिट करें। आवेदन स्थानीय तालुका आपूर्ति अधिकारी के पास सत्यापन के लिए भेजा जाता है।\"},\"status\":\"upcoming\"}],\"officialSource\":{\"name\":\"Food, Civil Supplies and Consumer Protection Department, Maharashtra (RCMS)\",\"url\":\"https://rcms.mahafood.gov.in/\",\"lastVerified\":\"2026-09-25\"}},{\"id\":\"non-creamy-layer-certificate\",\"name\":{\"en\":\"Non-Creamy Layer Certificate\",\"mr\":\"नॉन-क्रिमीलेअर प्रमाणपत्र\",\"hi\":\"नॉन-क्रीमी लेयर प्रमाण पत्र\"},\"description\":{\"en\":\"Statutory certificate issued to VJNT, OBC, and SBC category citizens establishing that household annual income is within the non-creamy layer threshold (under ₹8 Lakhs), required for reservation benefits in education and government employment.\",\"mr\":\"इतर मागासवर्गीय (ओबीसी), विमुक्त जाती व भटक्या जमाती (व्हीजेएनटी) आणि विशेष मागास प्रवर्ग (एसबीसी) प्रवर्गातील नागरिकांचे कौटुंबिक उत्पन्न ८ लाख रुपयांपेक्षा कमी असल्याचे प्रमाणित करणारे प्रमाणपत्र.\",\"hi\":\"ओबीसी, वीजेएनटी और एसबीसी श्रेणी के नागरिकों को जारी किया जाने वाला आधिकारिक प्रमाण पत्र जो यह प्रमाणित करता है कि वार्षिक पारिवारिक आय ₹8 लाख की सीमा से कम है।\"},\"category\":\"Revenue & Citizen Certificates\",\"state\":\"Maharashtra\",\"documents\":[\"Proof of Identity (Aadhaar Card / Voter ID)\",\"Proof of Address (Ration Card / Electricity Bill)\",\"Caste Certificate of the Applicant or Father\",\"Income Proof of past 3 consecutive financial years (Salary certificate / Form 16 / ITR / Talathi report)\",\"Self-Declaration and Affidavit in Form-B\"],\"steps\":[{\"id\":\"step-1-gather-caste-income-docs\",\"title\":{\"en\":\"Compile 3-Year Income and Caste Records\",\"mr\":\"३ वर्षांचे उत्पन्न व जात प्रमाणपत्र गोळा करा\",\"hi\":\"3 वर्ष के आय और जाति प्रमाण पत्र एकत्र करें\"},\"description\":{\"en\":\"Assemble Caste Certificate and continuous 3-year income documentation verifying family income remains under ₹8 Lakhs per annum.\",\"mr\":\"जात प्रमाणपत्र आणि कुटुंबाचे वार्षिक उत्पन्न ८ लाखांच्या मर्यादेत असल्याचे सिद्ध करणारे सलग ३ वर्षांचे उत्पन्न दाखले तयार ठेवा.\",\"hi\":\"जाति प्रमाण पत्र और परिवार की वार्षिक आय ₹8 लाख से कम होने की पुष्टि करने वाले लगातार 3 वर्षों के आय दस्तावेज तैयार रखें।\"},\"status\":\"current\"},{\"id\":\"step-2-login-and-apply\",\"title\":{\"en\":\"Log In to Aaple Sarkar & Select NCL\",\"mr\":\"आपले सरकारवर लॉगिन करून नॉन-क्रिमीलेअर निवडा\",\"hi\":\"आपले सरकार पर लॉगिन करें और नॉन-क्रीमी लेयर चुनें\"},\"description\":{\"en\":\"Log in to Aaple Sarkar, select Revenue Department services, and choose 'Non-Creamy Layer Certificate'.\",\"mr\":\"आपले सरकारवर लॉगिन करा, महसूल विभागाच्या सेवांमध्ये जाऊन 'नॉन-क्रिमीलेअर प्रमाणपत्र' निवडा.\",\"hi\":\"आपले सरकार पर लॉगिन करें, राजस्व विभाग सेवाओं में जाएं और 'नॉन-क्रीमी लेयर प्रमाण पत्र' चुनें।\"},\"status\":\"upcoming\"},{\"id\":\"step-3-fill-wealth-income\",\"title\":{\"en\":\"Provide Wealth, Agriculture & Income Details\",\"mr\":\"संपत्ती, शेतजमीन व उत्पन्नाचा तपशील भरा\",\"hi\":\"संपत्ति, कृषि भूमि और आय का विवरण भरें\"},\"description\":{\"en\":\"Fill details regarding agricultural landholding, residential properties, and gross annual income for each of the last 3 financial years.\",\"mr\":\"शेतजमीन, निवासी मालमत्ता आणि मागील ३ आर्थिक वर्षांतील एकूण उत्पन्नाचा तपशील नोंदवा.\",\"hi\":\"कृषि भूमि, आवासीय संपत्ति और पिछले 3 वित्तीय वर्षों में सकल वार्षिक आय का विवरण दर्ज करें।\"},\"status\":\"upcoming\"},{\"id\":\"step-4-upload-and-fee\",\"title\":{\"en\":\"Upload Documents and Pay Fee\",\"mr\":\"कागदपत्रे अपलोड करा व शुल्क भरा\",\"hi\":\"दस्तावेज अपलोड करें और शुल्क भरें\"},\"description\":{\"en\":\"Upload scanned caste and income documents and pay the prescribed fee online.\",\"mr\":\"जात व उत्पन्न पुराव्यांच्या स्कॅन केलेल्या प्रती अपलोड करा आणि विहित शुल्क ऑनलाइन भरा.\",\"hi\":\"जाति और आय प्रमाण दस्तावेजों की स्कैन प्रतियां अपलोड करें और निर्धारित शुल्क ऑनलाइन जमा करें।\"},\"status\":\"upcoming\"}],\"officialSource\":{\"name\":\"Aaple Sarkar — Revenue Department, Government of Maharashtra\",\"url\":\"https://aaplesarkar.mahaonline.gov.in/en/\",\"lastVerified\":\"2026-09-25\"}},{\"id\":\"senior-citizen-certificate\",\"name\":{\"en\":\"Senior Citizen Certificate\",\"mr\":\"ज्येष्ठ नागरिक प्रमाणपत्र\",\"hi\":\"वरिष्ठ नागरिक प्रमाण पत्र\"},\"description\":{\"en\":\"Official state identity certificate issued to citizens aged 60 years or above, enabling access to state transport concessions (MSRTC), healthcare benefits, and priority civic services.\",\"mr\":\"६० वर्षे किंवा त्याहून अधिक वयाच्या नागरिकांना जारी केलेले अधिकृत प्रमाणपत्र, ज्याद्वारे एसटी प्रवास सवलत (एसटी महामंडळ), आरोग्य लाभ आणि शासकीय सेवांमध्ये प्राधान्य मिळते.\",\"hi\":\"60 वर्ष या उससे अधिक आयु के नागरिकों को जारी आधिकारिक प्रमाण पत्र, जिससे राज्य परिवहन रियायतें (एमएसआरटीसी), स्वास्थ्य लाभ और प्राथमिकता सेवाएं प्राप्त होती हैं।\"},\"category\":\"Social Justice & Citizen Certificates\",\"state\":\"Maharashtra\",\"documents\":[\"Proof of Age (Birth Certificate / School Leaving Certificate / Passport / PAN Card / Driving Licence)\",\"Proof of Address (Ration Card / Electricity Bill / Voter ID)\",\"Proof of Identity (Aadhaar Card)\",\"Recent passport-sized photograph\",\"Medical Certificate (if applying on grounds of physical frailty or health concessions)\"],\"steps\":[{\"id\":\"step-1-gather-age-proof\",\"title\":{\"en\":\"Verify Age Document (Age 60+)\",\"mr\":\"वयाचा पुरावा तपासा (वय ६०+ वर्षे)\",\"hi\":\"आयु प्रमाण की पुष्टि करें (आयु 60+ वर्ष)\"},\"description\":{\"en\":\"Ensure you have an authentic government document verifying age 60 years or older (School Leaving Certificate, Birth Certificate, PAN, or Passport).\",\"mr\":\"वय ६० वर्षे पूर्ण झाल्याची खात्री देणारे अधिकृत सरकारी ओळखपत्र (शाळा सोडल्याचा दाखला, पॅन कार्ड, पासपोर्ट किंवा आधार) तयार ठेवा.\",\"hi\":\"सुनिश्चित करें कि आपके पास 60 वर्ष या उससे अधिक आयु का सत्यापन करने वाला वैध दस्तावेज (स्कूल छोड़ने का प्रमाण पत्र, पैन कार्ड, पासपोर्ट या आधार) उपलब्ध है।\"},\"status\":\"current\"},{\"id\":\"step-2-apply-aaple-sarkar\",\"title\":{\"en\":\"Apply Online via Aaple Sarkar\",\"mr\":\"आपले सरकारद्वारे ऑनलाइन अर्ज करा\",\"hi\":\"आपले सरकार के माध्यम से ऑनलाइन आवेदन करें\"},\"description\":{\"en\":\"Log in to Aaple Sarkar, select Social Justice and Special Assistance Department, and choose 'Senior Citizen Certificate'.\",\"mr\":\"आपले सरकार पोर्टलवर लॉगिन करा, सामाजिक न्याय व विशेष सहाय्य विभाग निवडून 'ज्येष्ठ नागरिक प्रमाणपत्र' सेवेवर क्लिक करा.\",\"hi\":\"आपले सरकार पर लॉगिन करें, सामाजिक न्याय और विशेष सहायता विभाग चुनें और 'वरिष्ठ नागरिक प्रमाण पत्र' पर क्लिक करें।\"},\"status\":\"upcoming\"},{\"id\":\"step-3-submit-and-track\",\"title\":{\"en\":\"Submit Details & Download Certificate\",\"mr\":\"तपशील सादर करा आणि प्रमाणपत्र मिळवा\",\"hi\":\"विवरण सबमिट करें और प्रमाण पत्र प्राप्त करें\"},\"description\":{\"en\":\"Submit the form and download the verified Senior Citizen Certificate once authorized by the Sub-Divisional Officer.\",\"mr\":\"माहिती भरून अर्ज सादर करा आणि उपविभागीय अधिकाऱ्यांच्या मंजुरीनंतर अधिकृत ज्येष्ठ नागरिक ओळखपत्र डाउनलोड करा.\",\"hi\":\"फॉर्म सबमिट करें और उप-विभागीय अधिकारी की स्वीकृति के बाद आधिकारिक वरिष्ठ नागरिक प्रमाण पत्र डाउनलोड करें।\"},\"status\":\"upcoming\"}],\"officialSource\":{\"name\":\"Social Justice and Special Assistance Department, Government of Maharashtra\",\"url\":\"https://sjsa.maharashtra.gov.in/\",\"lastVerified\":\"2026-09-25\"}}]");
	//#endregion
	//#region src/data/maharashtra/schemes.json
	var schemes_default = /*#__PURE__*/ JSON.parse("[{\"id\":\"rcsms-shikshan-shulkh-shishyavrutti\",\"name\":{\"en\":\"Rajarshi Chhatrapati Shahu Maharaj Shikshan Shulkh Shishyavrutti Yojna (EBC)\",\"mr\":\"राजर्षी छत्रपती शाहू महाराज शिक्षण शुल्क शिष्यवृत्ती योजना (ईबीसी)\",\"hi\":\"राजर्षि छत्रपति शाहू महाराज शिक्षण शुल्क छात्रवृत्ति योजना (ईबीसी)\"},\"state\":\"Maharashtra\",\"category\":\"Higher Education & Scholarships\",\"eligibility\":[\"Applicant must be an Indian citizen and permanent domicile of Maharashtra state\",\"Annual family income must not exceed ₹8,00,000 (Rupees Eight Lakhs)\",\"Admitted to government-approved higher, technical, or professional degree/diploma courses through CAP (Centralized Admission Process)\",\"Maximum of two children from the same family can avail the benefit of this scheme\",\"Minimum 50% attendance maintained during the ongoing academic semester or term\"],\"benefits\":[\"50% reimbursement of tuition fees for eligible professional and non-professional courses in government-aided and unaided colleges\",\"50% reimbursement of university examination fees\",\"Direct Benefit Transfer (DBT) deposited directly into student's Aadhaar-seeded bank account via MahaDBT portal\"],\"documents\":[\"Domicile Certificate of Maharashtra State\",\"Valid Income Certificate issued by competent Tehsildar (annual income under ₹8 Lakhs)\",\"HSC / SSC / Previous Semester Marksheet\",\"CAP (Centralized Admission Process) Allotment Letter\",\"Aadhaar Card linked with active bank account\",\"Fee Receipt of current academic year\",\"College Bona Fide Certificate\"],\"officialSource\":{\"name\":\"MahaDBT — Higher & Technical Education Department, Government of Maharashtra\",\"url\":\"https://mahadbt.maharashtra.gov.in/\",\"lastVerified\":\"2026-09-25\"},\"lastVerified\":\"2026-09-25\"},{\"id\":\"sanjay-gandhi-niradhar-yojna\",\"name\":{\"en\":\"Sanjay Gandhi Niradhar Anudan Yojna\",\"mr\":\"संजय गांधी निराधार अनुदान योजना\",\"hi\":\"संजय गांधी निराधार अनुदान योजना\"},\"state\":\"Maharashtra\",\"category\":\"Social Welfare & Pension Support\",\"eligibility\":[\"Resident of Maharashtra for at least 15 continuous years\",\"Destitute persons below 65 years of age, or persons with disability (40% or above), orphan children, or destitute women (widows, divorcees, deserted wives)\",\"Annual family income must not exceed ₹21,000 (for single beneficiary) or ₹50,000 (if family members exist)\",\"No adult earning member capable of supporting the applicant\"],\"benefits\":[\"Monthly financial pension assistance of ₹1,500 per month for a single destitute beneficiary\",\"Increased assistance of up to ₹1,500 per month for households with multiple eligible family dependents\",\"Direct DBT credit into the beneficiary's post office or nationalized bank account every month\"],\"documents\":[\"Age Proof (School Leaving Certificate / Civil Surgeon Certificate)\",\"Proof of 15 years Residence in Maharashtra (Domicile or Ration Card)\",\"Income Certificate issued by Tehsildar (annual income within ₹21,000/₹50,000 limit)\",\"Disability Certificate with minimum 40% disability (if applying under disability category)\",\"Death Certificate of husband (for widows) or court decree (for deserted/divorced women)\",\"Aadhaar Card and Bank Passbook copy\"],\"officialSource\":{\"name\":\"Social Justice and Special Assistance Department, Government of Maharashtra\",\"url\":\"https://sjsa.maharashtra.gov.in/\",\"lastVerified\":\"2026-09-25\"},\"lastVerified\":\"2026-09-25\"},{\"id\":\"majhi-ladki-bahin-yojna\",\"name\":{\"en\":\"Mukhyamantri Majhi Ladki Bahin Yojna\",\"mr\":\"मुख्यमंत्री माझी लाडकी बहीण योजना\",\"hi\":\"मुख्यमंत्री माझी लाड़की बहिन योजना\"},\"state\":\"Maharashtra\",\"category\":\"Women & Child Empowerment\",\"eligibility\":[\"Resident woman of Maharashtra state aged between 21 and 65 years\",\"Annual family income from all sources must not exceed ₹2,50,000 (Rupees Two Lakh Fifty Thousand)\",\"Beneficiary or family members must not be regular government employees or income tax payers\",\"Beneficiary family must hold yellow or orange ration card (or income certificate below ₹2.5 Lakhs)\",\"Bank account must be Aadhaar-linked and enabled for DBT (Direct Benefit Transfer)\"],\"benefits\":[\"Monthly direct financial assistance of ₹1,500 deposited directly into the woman's bank account\",\"Financial self-reliance support and nutrition empowerment for women and their families\"],\"documents\":[\"Aadhaar Card of the applicant woman\",\"Domicile Certificate or 15-year Maharashtra Residence Certificate (or Ration Card/Voter ID)\",\"Yellow or Orange Ration Card (or Tehsildar Income Certificate below ₹2.5 Lakhs)\",\"Aadhaar-linked Bank Passbook copy\",\"Self-Declaration Affidavit of compliance with scheme rules\"],\"officialSource\":{\"name\":\"Women and Child Development Department, Government of Maharashtra\",\"url\":\"https://www.maharashtra.gov.in/\",\"lastVerified\":\"2026-09-25\"},\"lastVerified\":\"2026-09-25\"},{\"id\":\"pm-kisan-maharashtra\",\"name\":{\"en\":\"PM-KISAN Samman Nidhi (Maharashtra State Implementation)\",\"mr\":\"प्रधानमंत्री किसान सन्मान निधी (महाराष्ट्र राज्य अंमलबजावणी)\",\"hi\":\"प्रधानमंत्री किसान सम्मान निधि (महाराष्ट्र राज्य कार्यान्वयन)\"},\"state\":\"Maharashtra\",\"category\":\"Agriculture & Farmer Welfare\",\"eligibility\":[\"Small and marginal landholder farmer families with cultivable land in their names in Maharashtra 7/12 land records\",\"Must not belong to institutional landholder or high-income exclusion categories (constitutional posts, income tax payers, retired pensioners receiving ₹10,000+ monthly)\",\"Aadhaar e-KYC must be completed and bank account must be seeded with Aadhaar\"],\"benefits\":[\"Direct income support of ₹6,000 per year transferred in three equal installments of ₹2,000 every four months\",\"Complementary Maharashtra State 'Namo Shetkari Mahasanman Nidhi Yojna' providing an additional ₹6,000 annually (total ₹12,000 per year for Maharashtra farmers)\"],\"documents\":[\"Updated 7/12 Land Record (Satbara Utara) and 8A Extract from Maharashtra Mahabhulekh\",\"Aadhaar Card with mobile number linked for e-KYC verification\",\"Active Bank Account details (Aadhaar NPCI-mapped)\",\"Self-Declaration of land ownership\"],\"officialSource\":{\"name\":\"Department of Agriculture & Farmers Welfare / PM-KISAN Portal\",\"url\":\"https://pmkisan.gov.in/\",\"lastVerified\":\"2026-09-25\"},\"lastVerified\":\"2026-09-25\"},{\"id\":\"divyang-self-employment-assistance\",\"name\":{\"en\":\"Financial Assistance to Persons with Disabilities for Self-Employment\",\"mr\":\"दिव्यांग व्यक्तींना स्वयंरोजगारासाठी आर्थिक सहाय्य योजना\",\"hi\":\"दिव्यांग व्यक्तियों को स्वरोजगार के लिए वित्तीय सहायता योजना\"},\"state\":\"Maharashtra\",\"category\":\"Disability Empowerment\",\"eligibility\":[\"Resident of Maharashtra with UDID or certified benchmark disability of 40% or higher\",\"Age between 18 and 50 years\",\"Annual family income within statutory ceiling (under ₹1,00,000)\",\"Completed certified vocational skill training or possess viable micro-enterprise project proposal\"],\"benefits\":[\"Seed capital financial grant and subsidized bank credit up to ₹1,50,000 for setting up small shops, kiosks, or micro-businesses\",\"Margin money subsidy provided by Maharashtra Divyang Finance and Development Corporation\"],\"documents\":[\"UDID Card or Civil Surgeon Disability Certificate (40%+ disability)\",\"Proof of Age and Domicile in Maharashtra\",\"Income Certificate issued by Tehsildar\",\"Project proposal / quotation for tools, machinery, or business setup\",\"Bank Account details and Aadhaar Card\"],\"officialSource\":{\"name\":\"Department of Empowerment of Persons with Disabilities, Maharashtra (Divyang Sahayak)\",\"url\":\"https://divyangsahayak.maharashtra.gov.in/\",\"lastVerified\":\"2026-09-25\"},\"lastVerified\":\"2026-09-25\"},{\"id\":\"shravanbal-sewa-nivruttivetan\",\"name\":{\"en\":\"Shravanbal Seva Rajya Nivruttivetan Yojna\",\"mr\":\"श्रावणबाळ सेवा राज्य निवृत्तीवेतन योजना\",\"hi\":\"श्रवणबाळ सेवा राज्य पेंशन योजना\"},\"state\":\"Maharashtra\",\"category\":\"Social Welfare & Pension Support\",\"eligibility\":[\"Senior citizen aged 65 years or older residing in Maharashtra for at least 15 continuous years\",\"Category A: Senior citizens whose names appear in the Central Government BPL list (annual income up to ₹21,000)\",\"Category B: Senior citizens not in BPL list but having annual household income under ₹50,000\"],\"benefits\":[\"Monthly pension of ₹1,500 per month deposited directly into beneficiary's bank account\",\"Social security support for elderly citizens without independent financial means\"],\"documents\":[\"Age Proof verifying 65+ years (School Leaving Certificate / Civil Surgeon Certificate / Voter ID)\",\"Domicile Certificate or 15-year Maharashtra residence proof\",\"Income Certificate issued by competent Revenue Authority (Tehsildar)\",\"BPL Card copy (for Category A applicants)\",\"Aadhaar Card and Bank Passbook\"],\"officialSource\":{\"name\":\"Social Justice and Special Assistance Department, Government of Maharashtra\",\"url\":\"https://sjsa.maharashtra.gov.in/\",\"lastVerified\":\"2026-09-25\"},\"lastVerified\":\"2026-09-25\"}]");
	//#endregion
	//#region src/core/shared/data-loader.ts
	var validatedPortals = portals_default.map((entry, index) => {
		if (!isPortal(entry)) throw new Error(`Invalid Portal entry in portals.json at index ${index}`);
		return entry;
	});
	services_default.map((entry, index) => {
		if (!isService(entry)) throw new Error(`Invalid Service entry in services.json at index ${index}`);
		return entry;
	});
	schemes_default.map((entry, index) => {
		if (!isScheme(entry)) throw new Error(`Invalid Scheme entry in schemes.json at index ${index}`);
		return entry;
	});
	/** Returns all verified government portals */
	function getPortals() {
		return [...validatedPortals];
	}
	/** Looks up a portal by official domain */
	function getPortalByDomain(domain) {
		const normalized = domain.toLowerCase();
		return validatedPortals.find((portal) => portal.domain.toLowerCase() === normalized);
	}
	//#endregion
	//#region src/core/portals/portal-detector.ts
	var PortalDetector = class {
		/**
		* Matches a URL string against the verified portals registry.
		*/
		static matchPortal(urlString, documentTitle) {
			if (!urlString || typeof urlString !== "string") return null;
			try {
				const parsedUrl = new URL(urlString);
				const hostname = parsedUrl.hostname.toLowerCase();
				const pathname = parsedUrl.pathname.toLowerCase();
				const directMatch = getPortalByDomain(hostname);
				if (directMatch) return {
					portalId: directMatch.id,
					confidence: "high",
					matchedBy: "domain"
				};
				const allPortals = getPortals();
				for (const portal of allPortals) {
					const portalDomain = portal.domain.toLowerCase();
					if (hostname.endsWith(portalDomain) || hostname.includes(portalDomain)) return {
						portalId: portal.id,
						confidence: "high",
						matchedBy: "domain"
					};
				}
				for (const portal of allPortals) if (pathname.includes(portal.id)) return {
					portalId: portal.id,
					confidence: "medium",
					matchedBy: "path"
				};
				if (documentTitle && typeof documentTitle === "string") {
					const normalizedTitle = documentTitle.toLowerCase();
					for (const portal of allPortals) if (normalizedTitle.includes(portal.name.toLowerCase()) || portal.id === "aaple-sarkar" && (normalizedTitle.includes("aaple sarkar") || normalizedTitle.includes("आपले सरकार")) || portal.id === "mahadbt" && (normalizedTitle.includes("mahadbt") || normalizedTitle.includes("महाडीबीटी"))) return {
						portalId: portal.id,
						confidence: "medium",
						matchedBy: "page_text"
					};
				}
				return null;
			} catch (_err) {
				const allPortals = getPortals();
				for (const portal of allPortals) if (urlString.toLowerCase().includes(portal.domain.toLowerCase())) return {
					portalId: portal.id,
					confidence: "high",
					matchedBy: "url"
				};
				return null;
			}
		}
		/**
		* Retrieves Portal object for a matched URL or returns undefined.
		*/
		static getPortalForUrl(urlString) {
			const match = this.matchPortal(urlString);
			if (!match) return void 0;
			return getPortals().find((p) => p.id === match.portalId);
		}
		/**
		* Returns whether a given URL is a known, supported government portal.
		*/
		static isKnownPortal(urlString) {
			const match = this.matchPortal(urlString);
			return match !== null && match.confidence !== "low";
		}
	};
	//#endregion
	//#region src/core/form-guides/form-guide-repository.ts
	var AAPLE_SARKAR_AUTH_GUIDE = {
		formId: "aaple-sarkar-login",
		portalId: "aaple-sarkar",
		name: {
			en: "Aaple Sarkar Citizen Portal Login & Access",
			mr: "आपले सरकार नागरिक पोर्टल लॉगिन व प्रवेश",
			hi: "आपले सरकार नागरिक पोर्टल लॉगिन और प्रवेश"
		},
		pages: [{
			id: "login-page",
			title: {
				en: "Citizen Authentication",
				mr: "नागरिक प्रमाणीकरण",
				hi: "नागरिक प्रमाणीकरण"
			},
			match: {
				urlPattern: "aaplesarkar.mahaonline.gov.in",
				requiredText: [
					"Citizen Login",
					"नागरिक लॉगिन",
					"Aaple Sarkar"
				],
				stableSelectors: [
					"#login_user_id",
					"#user_id",
					"#txtLoginId",
					"input[name='userId']"
				]
			},
			fields: [
				{
					id: "userId",
					selector: "#login_user_id, #user_id, #txtLoginId, input[name='userId'], #username",
					label: {
						en: "Registered Mobile Number or Username",
						mr: "नोंदणीकृत मोबाइल क्रमांक किंवा युझर आयडी",
						hi: "पंजीकृत मोबाइल नंबर या यूजर आईडी"
					},
					help: {
						en: "Enter your 10-digit mobile number or the username you chose when registering on Aaple Sarkar.",
						mr: "आपले सरकारवर नोंदणी करताना दिलेला १० अंकी मोबाइल नंबर किंवा वापरकर्ता नाव येथे टाका.",
						hi: "आपले सरकार पर पंजीकरण के समय दिया गया 10 अंकों का मोबाइल नंबर या यूजर आईडी यहां दर्ज करें।"
					},
					required: true,
					inputType: "text",
					explanation: {
						en: "This field verifies your identity as a registered Maharashtra citizen.",
						mr: "हा रकाना तुमची अधिकृत नागरिक ओळख पडताळण्यासाठी वापरला जातो.",
						hi: "यह फ़ील्ड आपकी पंजीकृत नागरिक पहचान सत्यापित करने के लिए उपयोग की जाती है।"
					}
				},
				{
					id: "captcha",
					selector: "#captcha, #txtCaptcha, input[name='captcha'], #captchaCode",
					label: {
						en: "Security Captcha Code",
						mr: "सुरक्षा कॅप्चा कोड",
						hi: "सुरक्षा कैप्चा कोड"
					},
					help: {
						en: "Type the exact characters and numbers displayed in the adjacent verification image.",
						mr: "शेजारील चित्रात दिसणारे इंग्रजी अक्षरे आणि अंक जसेच्या तसे येथे टाईप करा.",
						hi: "पास के सुरक्षा चित्र में दिखाए गए अक्षर और अंक यहां सही-सही टाइप करें।"
					},
					required: true,
					inputType: "text",
					explanation: {
						en: "The captcha proves you are a genuine human citizen and protects the government portal from automated bots.",
						mr: "कॅप्चा कोडमुळे तुम्ही स्वतः अर्ज भरत आहात याची खात्री होते आणि पोर्टल सुरक्षित राहते.",
						hi: "कैप्चा कोड सुनिश्चित करता है कि आप स्वयं आवेदन भर रहे हैं और पोर्टल सुरक्षित रहता है।"
					}
				},
				{
					id: "loginBtn",
					selector: "#btnLogin, #btnSubmit, input[type='submit'][value*='Login'], button[type='submit']",
					label: {
						en: "Login Button",
						mr: "लॉगिन / प्रवेश करा बटण",
						hi: "लॉगिन बटन"
					},
					help: {
						en: "After entering your mobile number, password, and captcha, click this button to access your citizen dashboard.",
						mr: "तपशील भरल्यानंतर पोर्टलवर प्रवेश करण्यासाठी या बटणावर क्लिक करा.",
						hi: "विवरण भरने के बाद पोर्टल में प्रवेश करने के लिए इस बटन पर क्लिक करें।"
					},
					required: true,
					inputType: "text",
					explanation: {
						en: "Clicking this submits your login details to open the services menu.",
						mr: "यावर क्लिक केल्यावर तुमचे खाते उघडेल आणि सेवांची यादी दिसेल.",
						hi: "इस पर क्लिक करने से आपका खाता खुलेगा और सेवाओं की सूची दिखाई देगी।"
					}
				}
			]
		}]
	};
	var INCOME_CERTIFICATE_FORM_GUIDE = {
		formId: "income-certificate-form",
		portalId: "aaple-sarkar",
		name: {
			en: "Income Certificate Application Form (Revenue Department)",
			mr: "उत्पन्नाचा दाखला अर्ज (महसूल विभाग)",
			hi: "आय प्रमाण पत्र आवेदन पत्र (राजस्व विभाग)"
		},
		pages: [{
			id: "applicant-details",
			title: {
				en: "Applicant & Family Details",
				mr: "अर्जदार व कौटुंबिक तपशील",
				hi: "आवेदक और पारिवारिक विवरण"
			},
			match: {
				urlPattern: "aaplesarkar.mahaonline.gov.in",
				requiredText: [
					"Income Certificate",
					"उत्पन्नाचे प्रमाणपत्र",
					"Revenue Department"
				],
				stableSelectors: [
					"#applicant_name",
					"#annual_income",
					"input[name='annualIncome']"
				]
			},
			fields: [
				{
					id: "applicantName",
					selector: "#applicant_name, #txtApplicantName, input[name='applicantName'], #fullName",
					label: {
						en: "Full Name of Applicant",
						mr: "अर्जदाराचे संपूर्ण नाव",
						hi: "आवेदक का पूरा नाम"
					},
					help: {
						en: "Enter the full name exactly as it appears on your Aadhaar card or School Leaving Certificate.",
						mr: "आधार कार्ड किंवा शाळा सोडल्याच्या दाखल्यावरील नावाप्रमाणेच संपूर्ण नाव अचूक प्रविष्ट करा.",
						hi: "आधार कार्ड या स्कूल लीविंग सर्टिफिकेट के अनुसार पूरा नाम सही दर्ज करें।"
					},
					required: true,
					inputType: "text",
					explanation: {
						en: "This name will be printed directly on the issued government income certificate.",
						mr: "हे नाव थेट शासकीय प्रमाणपत्रावर मुद्रित केले जाईल.",
						hi: "यह नाम सीधे सरकारी प्रमाण पत्र पर मुद्रित होगा।"
					}
				},
				{
					id: "annualIncome",
					selector: "#annual_income, #txtAnnualIncome, input[name='annualIncome'], #totalIncome",
					label: {
						en: "Annual Family Income (in INR ₹)",
						mr: "वार्षिक कौटुंबिक उत्पन्न (रुपयांमध्ये)",
						hi: "वार्षिक पारिवारिक आय (रुपये में)"
					},
					help: {
						en: "Enter total yearly income from all sources as verified by Talathi report, salary slip, or IT returns.",
						mr: "तलाठी अहवाल किंवा पगार पावतीनुसार सर्व मार्ग मिळून येणारे वार्षिक उत्पन्न येथे लिहा.",
						hi: "तलाठी रिपोर्ट या वेतन पर्ची के अनुसार सभी स्रोतों से वार्षिक आय यहां लिखें।"
					},
					required: true,
					inputType: "number",
					explanation: {
						en: "Government welfare scheme eligibility (e.g. EBC scholarship under ₹8L, Ladki Bahin under ₹2.5L) depends on this amount.",
						mr: "शासकीय योजनांची पात्रता (उदा. ईबीसी शिष्यवृत्ती ₹८ लाखांखाली) या उत्पन्नावर अवलंबून असते.",
						hi: "सरकारी योजनाओं की पात्रता (उदा. ईबीसी छात्रवृत्ति ₹8 लाख से कम) इसी आय पर निर्भर करती है।"
					}
				},
				{
					id: "reasonForCertificate",
					selector: "#reason, #txtReason, select[name='purpose'], #purpose",
					label: {
						en: "Purpose of Certificate",
						mr: "दाखल्याचा उद्देश / कारण",
						hi: "प्रमाण पत्र का उद्देश्य / कारण"
					},
					help: {
						en: "Select why you need this certificate (e.g. Education/Scholarship, Ration Card, or Welfare Scheme).",
						mr: "दाखला कशासाठी हवा आहे (उदा. शिक्षण/शिष्यवृत्ती, रेशन कार्ड किंवा योजना) ते निवडा.",
						hi: "प्रमाण पत्र किसलिए चाहिए (उदा. शिक्षा/छात्रवृत्ति, राशन कार्ड या योजना) वह चुनें।"
					},
					required: true,
					inputType: "select",
					explanation: {
						en: "Specifies the administrative validity of the certificate for that purpose.",
						mr: "प्रमाणपत्राचा अधिकृत वापर कशासाठी होणार आहे हे यातून स्पष्ट होते.",
						hi: "प्रमाण पत्र का आधिकारिक उपयोग किसलिए होगा यह इससे स्पष्ट होता है।"
					}
				}
			]
		}]
	};
	var REGISTERED_FORM_GUIDES = [AAPLE_SARKAR_AUTH_GUIDE, INCOME_CERTIFICATE_FORM_GUIDE];
	var FormGuideRepository = class {
		static getAllGuides() {
			return [...REGISTERED_FORM_GUIDES];
		}
		static getGuideById(formId) {
			return REGISTERED_FORM_GUIDES.find((g) => g.formId === formId);
		}
		static getGuidesForPortal(portalId) {
			return REGISTERED_FORM_GUIDES.filter((g) => g.portalId === portalId);
		}
		static matchGuide(url, pageText) {
			if (!url) return void 0;
			const lowerUrl = url.toLowerCase();
			const lowerText = (pageText || "").toLowerCase();
			for (const guide of REGISTERED_FORM_GUIDES) for (const page of guide.pages) {
				const urlMatch = !page.match.urlPattern || lowerUrl.includes(page.match.urlPattern.toLowerCase());
				const textMatch = !page.match.requiredText || page.match.requiredText.some((req) => lowerText.includes(req.toLowerCase()));
				if (urlMatch && (textMatch || !page.match.requiredText)) return guide;
			}
			if (lowerUrl.includes("aaplesarkar.mahaonline.gov.in")) {
				if (lowerUrl.includes("income") || lowerText.includes("income") || lowerText.includes("उत्पन्न")) return INCOME_CERTIFICATE_FORM_GUIDE;
				return AAPLE_SARKAR_AUTH_GUIDE;
			}
		}
	};
	//#endregion
	//#region extension/src/content/detector.ts
	var ContentDetector = class {
		/**
		* Safely inspects current document and window to extract minimum necessary page context.
		*/
		static extractPageContext(doc = document, win = window) {
			const url = win.location.href;
			const hostname = win.location.hostname;
			const title = doc.title || "";
			const headings = [];
			doc.querySelectorAll("h1, h2, .page-title, .portal-header").forEach((el, index) => {
				if (index < 4) {
					const text = el.textContent?.trim();
					if (text && text.length < 120) headings.push(text);
				}
			});
			const visibleText = headings.join(" • ");
			return {
				url,
				domain: hostname,
				title,
				portalId: PortalDetector.matchPortal(url, title)?.portalId,
				visibleText,
				detectedFormId: FormGuideRepository.matchGuide(url, visibleText)?.formId
			};
		}
		/**
		* Evaluates whether current page is a known government portal or unknown page.
		*/
		static detectPageStatus(doc = document, win = window) {
			const context = this.extractPageContext(doc, win);
			const isKnown = Boolean(context.portalId);
			return {
				portalId: context.portalId,
				formId: context.detectedFormId,
				status: isKnown ? "known" : "unknown",
				confidence: isKnown ? "high" : "low"
			};
		}
		/**
		* Returns active FormGuide for current page if available.
		*/
		static getCurrentFormGuide(doc = document, win = window) {
			const context = this.extractPageContext(doc, win);
			return FormGuideRepository.matchGuide(context.url || "", context.visibleText);
		}
	};
	//#endregion
	//#region extension/src/content/highlighter.ts
	/**
	* Sahayak AI Extension — DOM Field Highlighter
	* 
	* Source of Truth: docs/source-of-truth/ARCHITECTURE.md Section 28 & SECURITY.md Section 13-14
	* Phase: P08 — Browser Extension
	* 
	* Injects non-destructive accessible focus highlights onto verified form fields.
	* Security Invariants:
	* 1. Zero password field touch: Strictly rejects highlighting or touching input[type="password"].
	* 2. Zero payment frame touch: Never highlights elements in payment iframes.
	* 3. Zero automatic submission: Does not click submit buttons or submit forms.
	*/
	var HIGHLIGHT_CLASS_NAME = "sahayak-field-highlight";
	var HIGHLIGHT_STYLE_ID = "sahayak-extension-styles";
	/**
	* Ensures the Sahayak accessible highlight CSS styles are injected into document head.
	*/
	function ensureHighlightStylesInjected(doc = document) {
		if (doc.getElementById("sahayak-extension-styles")) return;
		const styleEl = doc.createElement("style");
		styleEl.id = HIGHLIGHT_STYLE_ID;
		styleEl.textContent = `
    .${HIGHLIGHT_CLASS_NAME} {
      outline: 3px solid #eb6e27 !important;
      outline-offset: 3px !important;
      box-shadow: 0 0 0 6px rgba(235, 110, 39, 0.25) !important;
      border-radius: 4px !important;
      transition: outline 0.2s ease-in-out, box-shadow 0.2s ease-in-out !important;
    }
  `;
		if (doc.head) doc.head.appendChild(styleEl);
		else if (doc.documentElement) doc.documentElement.appendChild(styleEl);
	}
	/**
	* Finds and highlights a form field element matching fieldId or selector.
	* Returns { success: boolean; error?: string }.
	*/
	function highlightField(fieldId, selector, doc = document) {
		ensureHighlightStylesInjected(doc);
		let element = null;
		if (selector && typeof selector === "string" && selector.trim().length > 0) try {
			element = doc.querySelector(selector);
		} catch (_err) {}
		if (!element && fieldId) element = doc.getElementById(fieldId);
		if (!element && fieldId) element = doc.querySelector(`[name="${fieldId}"]`);
		if (!element && fieldId) element = doc.querySelector(`input[data-field-id="${fieldId}"]`);
		if (!element) return {
			success: false,
			error: "FIELD_NOT_FOUND"
		};
		const inputEl = element;
		const inputType = (inputEl.type || "").toLowerCase();
		const inputName = (inputEl.name || "").toLowerCase();
		const inputId = (inputEl.id || "").toLowerCase();
		if (inputType === "password" || inputType === "hidden" || inputName.includes("password") || inputId.includes("password") || inputName.includes("cvv") || inputId.includes("cvv") || inputName.includes("pin") || inputId.includes("pin")) return {
			success: false,
			error: "SECURITY_REJECTION_PASSWORD_FIELD"
		};
		clearHighlight(void 0, doc);
		element.classList.add(HIGHLIGHT_CLASS_NAME);
		try {
			element.scrollIntoView({
				behavior: "smooth",
				block: "center",
				inline: "nearest"
			});
		} catch (_e) {
			element.scrollIntoView();
		}
		return { success: true };
	}
	/**
	* Removes highlight class from active elements.
	*/
	function clearHighlight(fieldId, doc = document) {
		if (fieldId) {
			const el = doc.getElementById(fieldId) || doc.querySelector(`[name="${fieldId}"]`);
			if (el) el.classList.remove(HIGHLIGHT_CLASS_NAME);
		}
		doc.querySelectorAll(`.${HIGHLIGHT_CLASS_NAME}`).forEach((el) => el.classList.remove(HIGHLIGHT_CLASS_NAME));
	}
	//#endregion
	//#region extension/src/content/content-script.ts
	if (typeof document !== "undefined") ensureHighlightStylesInjected();
	/**
	* Handles incoming ExtensionMessage and generates strongly typed ExtensionResponse.
	*/
	function handleContentScriptMessage(message, doc = document, win = window) {
		if (!isExtensionMessage(message)) return {
			success: false,
			error: {
				code: "UNKNOWN",
				message: "Invalid extension message structure."
			}
		};
		const typedMsg = message;
		switch (typedMsg.type) {
			case "GET_PAGE_CONTEXT": return {
				success: true,
				data: ContentDetector.extractPageContext(doc, win)
			};
			case "GET_CURRENT_FORM": {
				const guide = ContentDetector.getCurrentFormGuide(doc, win);
				if (!guide) return {
					success: false,
					error: {
						code: "FORM_NOT_DETECTED",
						message: "No verified form guide matches the current page."
					}
				};
				return {
					success: true,
					data: guide
				};
			}
			case "HIGHLIGHT_FIELD": {
				const res = highlightField(typedMsg.fieldId, typedMsg.selector, doc);
				if (!res.success) return {
					success: false,
					error: {
						code: res.error === "SECURITY_REJECTION_PASSWORD_FIELD" ? "PERMISSION_DENIED" : "FIELD_NOT_FOUND",
						message: res.error === "SECURITY_REJECTION_PASSWORD_FIELD" ? "Password and security credential fields cannot be highlighted or assisted." : `Field "${typedMsg.fieldId}" could not be located on the current page.`
					}
				};
				return { success: true };
			}
			case "CLEAR_HIGHLIGHT":
				clearHighlight(typedMsg.fieldId, doc);
				return { success: true };
			default: return {
				success: false,
				error: {
					code: "UNKNOWN",
					message: "Unhandled extension message type."
				}
			};
		}
	}
	if (typeof chrome !== "undefined" && chrome.runtime?.onMessage) chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
		sendResponse(handleContentScriptMessage(message));
		return true;
	});
	//#endregion
	exports.handleContentScriptMessage = handleContentScriptMessage;
	return exports;
})({});
